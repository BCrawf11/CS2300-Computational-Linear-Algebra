/*	
	Brodie Crawford
	CS 2300
	10/19/21
	Assignment 3, Part A
	Takes in a matrix A and a vector b from a file, and then
	solves the equation for vector x.
*/

import java.io.*;
import java.util.Scanner;

public class bcrawfo2_partA
{
	public static void main (String args[]) throws IOException
	{
		//reads from 4 different input files
		for (int i = 1; i <= 4; i++)
		{
			String inputPath = "C:\\Users\\brodi\\OneDrive\\Desktop\\Brodie\\College\\Fall 2021\\CS 2300\\Assignment 3\\test_input_" + i + ".txt";
			String outputPath = "C:\\Users\\brodi\\OneDrive\\Desktop\\Brodie\\College\\Fall 2021\\CS 2300\\Assignment 3\\bcrawfo2_partA_test_output_" + i + ".txt";
			File input = new File(inputPath);
			File output = new File(outputPath);
			
			if (!output.exists())
	        {
	            output.createNewFile();
	        }
			
			Scanner scan = new Scanner(input);
			BufferedWriter bw = new BufferedWriter(new FileWriter(output.getAbsoluteFile()));
			
			double[][] matA = {{0, 0}, {0, 0}};
			double[] vectorB = {0, 0};
			double[] vectorX = {0, 0};
			
			//reads matrix A and vector B from the input file
			while(scan.hasNext())
			{
				for (int j = 0; j < 2; j++)
				{
					matA[j][0] = scan.nextInt();
					matA[j][1] = scan.nextInt();
					vectorB[j] = scan.nextInt();
				}
			}
			
			//system inconsistent or underdetermined
			if (determinant(matA) == 0)
			{
				char c = detEqualToZero(matA, vectorB);
				
				if (c == 'i')
				{
					bw.write("System inconsistent.");
				}
				else if (c == 'u')
				{
					bw.write("System underdetermined.");
				}
				else if (c == 'd')
				{
					bw.write("Error in calculating system.");
				}
			}
			//system ok to solve
			else
			{
				vectorX = solveForX(matA, vectorB);
				bw.write(String.valueOf(vectorX[0]) + "\n");
				bw.write(String.valueOf(vectorX[1]));
			}
			
			bw.close();
			scan.close();
		}
	}
	
	public static double determinant(double[][] matrix)
	{
		return (matrix[0][0] * matrix[1][1]) - (matrix[0][1] * matrix[1][0]);
	}
	
	public static double[][] inverse(double[][] matrix)
	{
		double det = determinant(matrix);
		
		double[][] inverseMatrix = {{ matrix[1][1]/det, -matrix[0][1]/det },
				{ -matrix[1][0]/det, matrix[0][0]/det }};
		
		return inverseMatrix;
	}
	
	public static double[] solveForX(double[][] matrix, double[] vectorb)
	{
		double[][] iMat = inverse(matrix);
		
		double e = iMat[0][0];
		double f = iMat[0][1];
		double g = iMat[1][0];
		double h = iMat[1][1];
		double b1 = vectorb[0];
		double b2 = vectorb[1];
		
		double[] vectorX = { (e*b1) + (f*b2), (g*b1) + (h*b2) };
		
		return vectorX;
	}
	
	public static char detEqualToZero(double[][] matrix, double[] vectorb)
	{
		double a = matrix[0][0];
		double b = matrix[0][1];
		double c = matrix[1][0];
		double d = matrix[1][1];
		double b1 = vectorb[0];
		double b2 = vectorb[1];
		double x1 = 0, x2 = 0;
		boolean flag = false;
		
		if (b != 0)
		{
			x1 = 1;
			x2 = (b1 - a)/b;
			flag = true;
		}
		
		if (b == 0 && a != 0)
		{
			x2 = 1;
			x1 = b1/a;
			flag = true;
		}
		
		//both a and b are zero, no solutions (parallel lines)
		if (b == 0 && a == 0 && b1 != 0)
		{
			return 'i';
		}
		
		//both a and b are zero, all solutions (the same line)
		if (b == 0 && a == 0 && b1 == 0)
		{
			return 'u';
		}
		
		//if x1 and x2 are computable with b and a values
		if (flag == true)
		{
			if ((c*x1) + (d*x2) != b2)
			{
				return 'i';
			}
			if ((c*x1) + (d*x2) == b2)
			{
				return 'u';
			}
		}
		
		//default flag
		return 'd';
	}
}
