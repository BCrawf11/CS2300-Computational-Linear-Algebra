/*	
	Brodie Crawford
	CS 2300
	10/19/21
	Assignment 3, Part B
	Takes in a matrix A from a few input files, and then
	finds eigenvalues and eigenvectors, as well as doing
	eigendecomposition.
*/

import java.io.*;
import java.util.Scanner;
import java.text.DecimalFormat;

public class bcrawfo2_partB
{
	public static void main (String args[]) throws IOException
	{		
		//reads from 4 different input files
		for (int i = 1; i <= 4; i++)
		{
			String inputPath = "C:\\Users\\brodi\\OneDrive\\Desktop\\Brodie\\College\\Fall 2021\\CS 2300\\Assignment 3\\test_input_" + i + ".txt";
			String outputPath = "C:\\Users\\brodi\\OneDrive\\Desktop\\Brodie\\College\\Fall 2021\\CS 2300\\Assignment 3\\bcrawfo2_partB_test_output_" + i + ".txt";
			File input = new File(inputPath);
			File output = new File(outputPath);
			
			if (!output.exists())
	        {
	            output.createNewFile();
	        }
			
			Scanner scan = new Scanner(input);
			BufferedWriter bw = new BufferedWriter(new FileWriter(output.getAbsoluteFile()));
			
			double[][] matA = {{0, 0}, {0, 0}};
			double[][] matCarat = {{0, 0}, {0, 0}};
			double[][] matR = {{0, 0}, {0, 0}};
			double[][] matRT = {{0, 0}, {0, 0}};
			
			//reads matrix A from the input file
			while(scan.hasNext())
			{
				for (int j = 0; j < 2; j++)
				{
					matA[j][0] = scan.nextInt();
					matA[j][1] = scan.nextInt();
				}
			}
			
			double[] eValues = eigenvalues(matA);
			
			//get the matrix ^
			matCarat[0][0] = eValues[0];
			matCarat[1][1] = eValues[1];
			
			//decimal formatter to print nice output
			DecimalFormat dF = new DecimalFormat();
			dF.setMinimumFractionDigits(4);
			
			//write matrix ^ to file
			bw.write(String.valueOf(dF.format(matCarat[0][0])) + " " + String.valueOf(dF.format(matCarat[0][1])));
			bw.newLine();
			bw.write(String.valueOf(dF.format(matCarat[1][0])) + " " + String.valueOf(dF.format(matCarat[1][1])));
			bw.newLine();
			
			//get eigenvectors
			double[] eV1 = eigenvector(matA, eValues[0]);
			double[] eV2 = eigenvector(matA, eValues[1]);
			
			//assemble matrix R by putting eigenvectors into matrix
			matR[0][0] = eV1[0];
			matR[1][0] = eV1[1];
			matR[0][1] = eV2[0];
			matR[1][1] = eV2[1];
			
			//write matrix R to file
			bw.write(String.valueOf(dF.format(matR[0][0])) + " " + String.valueOf(dF.format(matR[0][1])));
			bw.newLine();
			bw.write(String.valueOf(dF.format(matR[1][0])) + " " + String.valueOf(dF.format(matR[1][1])));
			bw.newLine();
			
			//transpose matrix R to get matrix RT
			matRT = matR;
			matRT[1][0] = matR[0][1];
			matRT[0][1] = matR[1][0];
			
			//multiply matrices R, ^, and RT together
			double[][] rart = multiply2x2Matrices(multiply2x2Matrices(matR, matCarat), matRT);
			
			bw.write(String.valueOf(dF.format(rart[0][0])) + " " + String.valueOf(dF.format(rart[0][1])));
			bw.newLine();
			bw.write(String.valueOf(dF.format(rart[1][0])) + " " + String.valueOf(dF.format(rart[1][1])));
			bw.newLine();
			
			//checks if A is equal to R^RT
			if (matA[0][0] == rart[0][0] && matA[0][1] == rart[0][1] &&
					matA[1][0] == rart[1][0] && matA[1][1] == rart[1][1])
			{
				bw.write(String.valueOf(1));
			}
			else
			{
				bw.write(String.valueOf(0));
			}
			
			bw.close();
			scan.close();
		}
	}
	
	public static double[] eigenvalues(double[][] A)
	{		
		double a = A[0][0];
		double b = A[0][1];
		double c = A[1][0];
		double d = A[1][1];
		double e1 = 0;
		double e2 = 0;
		double[] eValues = {0, 0};
		
		e1 = ((a + d) + (Math.sqrt(Math.pow(-(a + d), 2) - (4 * ((a*d) - (b*c))))))/2;
		e2 = ((a + d) - (Math.sqrt(Math.pow(-(a + d), 2) - (4 * ((a*d) - (b*c))))))/2;
		
		eValues[0] = e1;
		eValues[1] = e2;
		
		return eValues;
	}
	
	public static double[] eigenvector(double[][] matA, double eValue)
	{
		double A = matA[0][0] - eValue;
		double b = matA[0][1];
		double c = matA[1][0];
		double D = matA[1][1] - eValue;
		double[] eV = { 0, 0 };
		double[][] curMat = {{ A, b }, { c, D }};
		boolean columnPivot = false;
		double rNorm;
		
		//row pivot
		if (A == 0 && c != 0)
		{
			curMat[0][0] = c;
			curMat[0][1] = D;
			curMat[1][0] = A;
			curMat[1][1] = b;
		}
		//column pivot
		else if (A == 0 && c == 0 && b != 0)
		{
			curMat[0][0] = b;
			curMat[0][1] = A;
			curMat[1][0] = D;
			curMat[1][1] = c;
			
			//flag for column pivot
			columnPivot = true;
		}
		//no non-trivial eigenvector exists
		else if (A == 0 && c == 0 && b == 0)
		{
			//return flag
			return new double[] { 0, 0 };
		}
		
		//prepare for gaussian elimination
		A = curMat[0][0];
		b = curMat[0][1];
		c = curMat[1][0];
		D = curMat[1][1];
		
		//check if vector is trivial
		if ((((-b * c)/A) + D) == 0)
		{
			rNorm = Math.sqrt(Math.pow(b * A, 2) + 1);
			
			//swap r1 and r2 if there was a column pivot
			if (columnPivot)
			{
				eV[0] = 1/rNorm;
				eV[1] = (-b)/(A * rNorm);
			}
			//set r1 and r2 if no column pivot
			else
			{
				eV[0] = (-b)/(A * rNorm);
				eV[1] = 1/rNorm;
			}
		}
		else
		{
			//trivial vector
			return new double[] { 0, 0 };
		}
		
		return eV;
	}
	
	public static double[][] multiply2x2Matrices(double[][] matrix1, double[][] matrix2)
	{
		double[][] newMat = {{0, 0}, {0, 0}};
		
		//do the dot product of the different rows and columns
		newMat[0][0] = (matrix1[0][0] * matrix2[0][0]) + (matrix1[0][1] * matrix2[1][0]);
		newMat[0][1] = (matrix1[0][0] * matrix2[0][1]) + (matrix1[0][1] * matrix2[1][1]);
		newMat[1][0] = (matrix1[1][0] * matrix2[0][0]) + (matrix1[1][1] * matrix2[1][0]);
		newMat[1][1] = (matrix1[1][0] * matrix2[0][1]) + (matrix1[1][1] * matrix2[1][1]);
		
		return newMat;
	}
}
