/*	
	Brodie Crawford
	CS 2300
	10/19/21
	Assignment 3, Part C
	Takes in 3 points from the input files, and then finds the
	area of the triangle enclosed by the first 2 vectors for
	both 2D and 3D. If 2D, finds the distance of the 3rd point
	to the line made by the other 2 points. If 3D, finds the
	distance of the 3rd point to the plane made by the other 2
	points.
*/

import java.io.*;
import java.util.Scanner;
import java.text.DecimalFormat;

public class bcrawfo2_partC
{
	public static void main (String args[]) throws IOException
	{
		//reads from 4 different 2D input files
		for (int i = 1; i <= 4; i++)
		{
			String inputPath = "C:\\Users\\brodi\\OneDrive\\Desktop\\Brodie\\College\\Fall 2021\\CS 2300\\Assignment 3\\test_input_" + i + ".txt";
			String outputPath = "C:\\Users\\brodi\\OneDrive\\Desktop\\Brodie\\College\\Fall 2021\\CS 2300\\Assignment 3\\bcrawfo2_partC_test_output_" + i + ".txt";
			File input = new File(inputPath);
			File output = new File(outputPath);
			
			if (!output.exists())
	        {
	            output.createNewFile();
	        }
			
			Scanner scan = new Scanner(input);
			BufferedWriter bw = new BufferedWriter(new FileWriter(output.getAbsoluteFile()));
			
			double[] p1 = { 0, 0 };
			double[] p2 = { 0, 0 };
			double[] p3 = { 0, 0 };
			
			//reads 3 points from the file
			while(scan.hasNext())
			{
				for (int j = 0; j < 2; j++)
				{
					p1[j] = scan.nextInt();
					p2[j] = scan.nextInt();
					p3[j] = scan.nextInt();
				}
			}
			
			DecimalFormat dF = new DecimalFormat();
			dF.setMinimumFractionDigits(4);
			
			//find the area of the 2D triangle enclosed by the first two vectors and write it to the output file
			bw.write(String.valueOf(dF.format(findAreaOf2DTriangle(p1, p2, p3))));
			bw.newLine();
			bw.write(String.valueOf(dF.format(distanceFromPointToLine2D(p1, p2, p3))));
			
			bw.close();
			scan.close();
		}
		
		//reads from 2 different 3D input files
		for (int i = 1; i <= 2; i++)
		{
			String inputPath = "C:\\Users\\brodi\\OneDrive\\Desktop\\Brodie\\College\\Fall 2021\\CS 2300\\Assignment 3\\3D_test_input_" + i + ".txt";
			String outputPath = "C:\\Users\\brodi\\OneDrive\\Desktop\\Brodie\\College\\Fall 2021\\CS 2300\\Assignment 3\\bcrawfo2_partC_3D_test_output_" + i + ".txt";
			File input = new File(inputPath);
			File output = new File(outputPath);
			
			if (!output.exists())
	        {
	            output.createNewFile();
	        }
			
			Scanner scan = new Scanner(input);
			BufferedWriter bw = new BufferedWriter(new FileWriter(output.getAbsoluteFile()));
			
			double[] p1 = { 0, 0, 0 };
			double[] p2 = { 0, 0, 0 };
			double[] p3 = { 0, 0, 0 };
			
			//read the 3 points in from the file
			while(scan.hasNext())
			{
				for (int j = 0; j < 3; j++)
				{
					p1[j] = scan.nextInt();
					p2[j] = scan.nextInt();
					p3[j] = scan.nextInt();
				}
			}
			
			DecimalFormat dF = new DecimalFormat();
			dF.setMinimumFractionDigits(4);
			
			//find the area of the 2D triangle enclosed by the first two vectors and write it to the output file
			bw.write(String.valueOf(dF.format(findAreaOf3DTriangle(p1, p2, p3))));
			bw.newLine();
			bw.write(String.valueOf(dF.format(distanceFromPointToPlane3D(p1, p2, p3))));
			
			bw.close();
			scan.close();
		}
	}
	
	public static double findAreaOf2DTriangle(double[] p1, double[] p2, double[] p3)
	{
		double area = 0;
		double[] a1 = { 0, 0 };
		double[] a2 = { 0, 0 };
		
		//vector a1
		a1[0] = p2[0] - p1[0];
		a1[1] = p2[1] - p1[1];
		
		//vector a2
		a2[0] = p3[0] - p1[0];
		a2[1] = p3[1] - p1[1];
		
		//calculates the area of the triangle enclosed by a1 and a2
		area = Math.abs(0.5 * ((a1[0] * a2[1]) - (a1[1] * a2[0])));
		
		return area;
	}
	
	public static double distanceFromPointToLine2D(double[] p1, double[] p2, double[] p3)
	{
		double distance = 0;
		double[] v = { 0, 0 };
		double[] w = { 0, 0 };
		double vMag = 0;
		double wMag = 0;
		double cosa = 0;
		
		//vector v
		v[0] = p2[0] - p1[0];
		v[1] = p2[1] - p1[1];
		
		//vector w
		w[0] = p3[0] - p1[0];
		w[1] = p3[1] - p1[1];
		
		//find the magnitudes of v and w
		vMag = Math.sqrt(Math.pow(v[0], 2) + Math.pow(v[1], 2));
		wMag = Math.sqrt(Math.pow(w[0], 2) + Math.pow(w[1], 2));
		
		//compute cos(a) = (v dot w)/(||v|| ||w||)
		cosa = ((v[0] * w[0]) + (v[1] * w[1]))/(vMag * wMag);
		
		//find distance by substituting cos(a) into equation
		distance = wMag * (Math.sqrt(1 - Math.pow(cosa, 2)));
		
		return distance;
	}
	
	public static double findAreaOf3DTriangle(double[] p1, double[] p2, double[] p3)
	{
		double area = 0;
		double[] a1 = { 0, 0, 0 };
		double[] a2 = { 0, 0, 0 };
		double[] crossProd = { 0, 0, 0 };
		double magnitude = 0;
		
		//vector a1
		a1[0] = p2[0] - p1[0];
		a1[1] = p2[1] - p1[1];
		a1[2] = p2[2] - p1[2];
		
		//vector a2
		a2[0] = p3[0] - p1[0];
		a2[1] = p3[1] - p1[1];
		a2[2] = p3[2] - p1[2];
		
		//takes the cross product of a1 and a2
		crossProd[0] = (a1[1] * a2[2]) - (a1[2] * a2[1]);
		crossProd[1] = -((a1[0] * a2[2]) - (a1[2] * a2[0]));
		crossProd[2] = (a1[0] * a2[1]) - (a1[1] * a2[0]);
		
		//gets the magnitude and the area of the cross product vector
		magnitude = Math.sqrt(Math.pow(crossProd[0], 2) + Math.pow(crossProd[1], 2) + Math.pow(crossProd[2], 2));
		area = Math.abs(0.5 * (magnitude));
		
		return area;
	}
	
	public static double distanceFromPointToPlane3D(double[] p1, double[] p2, double[] p3)
	{
		double distance = 0;
		double[] m = { 0, 0, 0 };
		double[] n = { 0, 0, 0 };
		double[] o = { 0, 0, 0 };
		double oMag = 0;
		
		//get midway point
		m[0] = (p2[0] + p1[0])/2;
		m[1] = (p2[1] + p1[1])/2;
		m[2] = (p2[2] + p1[2])/2;
		
		//get vector o, which is p2 - p1
		o[0] = p2[0] - p1[0];
		o[1] = p2[1] - p1[1];
		o[2] = p2[2] - p1[2];
		
		oMag = Math.sqrt(Math.pow(o[0], 2) + Math.pow(o[1], 2) + Math.pow(o[2], 2));
		
		//get the unit length vector normal to the plane
		n[0] = o[0]/oMag;
		n[1] = o[1]/oMag;
		n[2] = o[2]/oMag;
		
		//computes n1p3,1 + n2p3,2 + n3p3,3 - (n1m1 + n2m2 + n3m3) to find the distance
		distance = (n[0] * p3[0]) + (n[1] * p3[1]) + (n[2] * p3[2]) - ((n[0] * m[0]) + (n[1] * m[1]) + (n[2] * m[2]));
		
		return distance;
	}
}
